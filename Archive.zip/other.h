//
// Created by Howard Ma on 2021/5/23.
//

#ifndef HW4_OTHER_H
#define HW4_OTHER_H
#include <string>

std::string ask_name(int num);
int ask_game_mode();
int ask_ai_mode();
#endif //HW4_OTHER_H
